//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
  TButton *Button1;
  TImage *Image1;
  TTimer *Timer1;
  void __fastcall Button1Click(TObject *Sender);
  void __fastcall Image1MouseDown(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y);
  void __fastcall Timer1Timer(TObject *Sender);
  void __fastcall FormCreate(TObject *Sender);
private:	// User declarations
public:		// User declarations
  __fastcall TForm1(TComponent* Owner);

};
float getV(int a1,int a2,int a3,int b1,int b2,int b3,int c1,int c2,int c3);
void setV(int a1,int a2,int a3,int b1,int b2,int b3,int c1,int c2,int c3,float v);
void initV(void);
void stepAI(void);
void readMap(int m1);
void paintMap();
int checkEnd();
void learnAI(int res);
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
