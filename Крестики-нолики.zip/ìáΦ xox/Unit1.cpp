//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
int m_click;
int xo_num;
float V[19683]; // X - 1, O - 2
int m[10],rm[10];
int var[10];   //vozmojnie varianti
int c_var;
int steps;
int steps_m[10];
float A;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
float getV(int a1,int a2,int a3,int b1,int b2,int b3,int c1,int c2,int c3)
{
int num;
num = ((((((((a1*3)+a2)*3+a3)*3+b1)*3+b2)*3+b3)*3+c1)*3+c2)*3+c3;
return V[num];
}
//---------------------------------------------------------------------------
void setV(int a1,int a2,int a3,int b1,int b2,int b3,int c1,int c2,int c3,float v)
{
int num;
num = ((((((((a1*3)+a2)*3+a3)*3+b1)*3+b2)*3+b3)*3+c1)*3+c2)*3+c3;
V[num] = v;
}
//---------------------------------------------------------------------------
void stepAI(void)
{
int flag;
c_var=0;
for (int i=0;i<19683;i++)
  {
  flag=0;
  readMap(i);
  for (int j=1; j<10;j++)
    if (rm[j]!=m[j])
      if ((m[j]==0) &&  (rm[j]==1)) flag++;
      else flag+=2;
  if (flag==1) {
    var[c_var]=i;
    c_var++;
  }
}
float v_max;
int v_num_max;
if (random(100)<5) v_num_max=random(c_var);
else {
  v_max = V[var[0]];
  v_num_max = 0;
  if (c_var>1)
  for (int i=1;i<c_var;i++)
    if (V[var[i]]>v_max)
     v_num_max = i;
  }

steps++;
steps_m[steps]=var[v_num_max];
readMap(var[v_num_max]);
for (int i=1;i<10;i++)
  m[i]=rm[i];

paintMap();
}
//---------------------------------------------------------------------------
void readMap(int m1)
{
int st;
st = m1;
for (int i=9;i>0;i--) {
  rm[i]=st%3;
  st=st/3;
  }
}
//---------------------------------------------------------------------------
int checkEnd()
{
if (m[1]==m[2] && m[2]==m[3] && m[3]==1) return 1;
if (m[4]==m[5] && m[5]==m[6] && m[6]==1) return 1;
if (m[7]==m[8] && m[8]==m[9] && m[9]==1) return 1;
if (m[1]==m[4] && m[4]==m[7] && m[7]==1) return 1;
if (m[2]==m[5] && m[5]==m[8] && m[8]==1) return 1;
if (m[3]==m[6] && m[6]==m[9] && m[9]==1) return 1;
if (m[1]==m[5] && m[5]==m[9] && m[9]==1) return 1;
if (m[7]==m[5] && m[5]==m[3] && m[3]==1) return 1;

if (m[1]==m[2] && m[2]==m[3] && m[3]==2) return 2;
if (m[4]==m[5] && m[5]==m[6] && m[6]==2) return 2;
if (m[7]==m[8] && m[8]==m[9] && m[9]==2) return 2;
if (m[1]==m[4] && m[4]==m[7] && m[7]==2) return 2;
if (m[2]==m[5] && m[5]==m[8] && m[8]==2) return 2;
if (m[3]==m[6] && m[6]==m[9] && m[9]==2) return 2;
if (m[1]==m[5] && m[5]==m[9] && m[9]==2) return 2;
if (m[7]==m[5] && m[5]==m[3] && m[3]==2) return 2;

return 0;
}
//---------------------------------------------------------------------------
void paintMap()
{
Form1->Image1->Canvas->Rectangle(0,0,201,201);
Form1->Image1->Canvas->MoveTo(66,10);
Form1->Image1->Canvas->LineTo(66,190);
Form1->Image1->Canvas->MoveTo(133,10);
Form1->Image1->Canvas->LineTo(133,190);
Form1->Image1->Canvas->MoveTo(10,66);
Form1->Image1->Canvas->LineTo(190,66);
Form1->Image1->Canvas->MoveTo(10,133);
Form1->Image1->Canvas->LineTo(190,133);     

for (int i=1;i<10;i++) {
  if (m[i]==1) {
  Form1->Image1->Canvas->MoveTo(((i-1)%3)*66+10,((i-1)/3)*66+10);
  Form1->Image1->Canvas->LineTo(((i-1)%3+1)*66-10,((i-1)/3+1)*66-10);
  Form1->Image1->Canvas->MoveTo(((i-1)%3)*66+10,((i-1)/3+1)*66-10);
  Form1->Image1->Canvas->LineTo(((i-1)%3+1)*66-10,((i-1)/3)*66+10);
  }
  if (m[i]==2)
  Form1->Image1->Canvas->Ellipse(((i-1)%3)*66+10,((i-1)/3)*66+10,((i-1)%3+1)*66-10,((i-1)/3+1)*66-10);
  }
}
//---------------------------------------------------------------------------
void initV()
{
for (int i1=0;i1<3;i1++)
for (int i2=0;i2<3;i2++)
for (int i3=0;i3<3;i3++)
for (int i4=0;i4<3;i4++)
for (int i5=0;i5<3;i5++)
for (int i6=0;i6<3;i6++)
for (int i7=0;i7<3;i7++)
for (int i8=0;i8<3;i8++)
for (int i9=0;i9<3;i9++)
{

setV(i1,i2,i3,i4,i5,i6,i7,i8,i9,0.5);

if (i1==i2 && i2==i3 && i3==1) setV(i1,i2,i3,i4,i5,i6,i7,i8,i9,1);
if (i4==i5 && i5==i6 && i6==1) setV(i1,i2,i3,i4,i5,i6,i7,i8,i9,1);
if (i7==i8 && i8==i9 && i9==1) setV(i1,i2,i3,i4,i5,i6,i7,i8,i9,1);
if (i1==i5 && i5==i9 && i9==1) setV(i1,i2,i3,i4,i5,i6,i7,i8,i9,1);
if (i7==i5 && i5==i3 && i3==1) setV(i1,i2,i3,i4,i5,i6,i7,i8,i9,1);
if (i1==i4 && i4==i7 && i7==1) setV(i1,i2,i3,i4,i5,i6,i7,i8,i9,1);
if (i2==i5 && i5==i8 && i8==1) setV(i1,i2,i3,i4,i5,i6,i7,i8,i9,1);
if (i3==i6 && i6==i9 && i9==1) setV(i1,i2,i3,i4,i5,i6,i7,i8,i9,1);

if (i1==i2 && i2==i3 && i3==2) setV(i1,i2,i3,i4,i5,i6,i7,i8,i9,0);
if (i4==i5 && i5==i6 && i6==2) setV(i1,i2,i3,i4,i5,i6,i7,i8,i9,0);
if (i7==i8 && i8==i9 && i9==2) setV(i1,i2,i3,i4,i5,i6,i7,i8,i9,0);
if (i1==i5 && i5==i9 && i9==2) setV(i1,i2,i3,i4,i5,i6,i7,i8,i9,0);
if (i7==i5 && i5==i3 && i3==2) setV(i1,i2,i3,i4,i5,i6,i7,i8,i9,0);
if (i1==i4 && i4==i7 && i7==2) setV(i1,i2,i3,i4,i5,i6,i7,i8,i9,0);
if (i2==i5 && i5==i8 && i8==2) setV(i1,i2,i3,i4,i5,i6,i7,i8,i9,0);
if (i3==i6 && i6==i9 && i9==2) setV(i1,i2,i3,i4,i5,i6,i7,i8,i9,0);
}

}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{

xo_num=0;
randomize();
steps=0;
paintMap;
for (int i=1;i<10;i++) m[i]=0;
Timer1->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Image1MouseDown(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
  int x0,y0;
  m_click = 1;
  x0 = X/66;
  y0 = Y/66;
  xo_num = y0*3+x0+1;
  m[xo_num]=2;
  paintMap();
  Timer1->Enabled = true;
  checkEnd();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
stepAI();
Timer1->Enabled = false;
if (checkEnd()==1) {
  ShowMessage("Win PC!");
  learnAI(1);
  Button1->Click();
  }
if (checkEnd()==2) {
  ShowMessage("You win!");
  learnAI(0);
  Button1->Click();
  }
if (steps==5) {
  learnAI(0);
  Button1->Click();
  }
}
//---------------------------------------------------------------------------
void learnAI(int res)
{
for (int i=0;i<steps;i++)
  V[steps_m[i]] += A * (res - V[steps_m[i]]);
A -= 0.01;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
A=0.95;
initV();
}
//---------------------------------------------------------------------------

